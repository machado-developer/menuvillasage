import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Download } from "lucide-react";
import QRCode from "qrcode";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/qr")({
  head: () => ({
    meta: [
      { title: "QR Code do Menu — Villa Sage" },
      { name: "description", content: "Descarregue o QR Code do menu digital Villa Sage para mesas e cartazes." },
      { property: "og:title", content: "QR Code do Menu — Villa Sage" },
      { property: "og:description", content: "QR Code para abrir o menu digital do Villa Sage." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: QrPage,
});

const PREVIEW_HOST = /id-preview--|lovableproject\.com|localhost/;

function QrPage() {
  const [url, setUrl] = useState("");
  const [preview, setPreview] = useState("");

  useEffect(() => setUrl(window.location.origin + "/"), []);

  useEffect(() => {
    if (!url) return;
    QRCode.toDataURL(url, { width: 2048, margin: 2, errorCorrectionLevel: "H", color: { dark: "#0f2a20", light: "#ffffff" } })
      .then(setPreview)
      .catch(() => setPreview(""));
  }, [url]);

  const isTemp = PREVIEW_HOST.test(url);

  return (
    <div className="mx-auto min-h-screen max-w-lg px-5 py-10">
      <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-gold">
        <ArrowLeft className="h-4 w-4" /> Voltar ao menu
      </Link>
      <h1 className="mt-6 font-display text-5xl">QR Code do menu</h1>
      <p className="mt-2 text-muted-foreground">Imprima nas mesas, cartazes e materiais promocionais.</p>

      <label className="mt-8 block text-sm text-muted-foreground">Endereço do menu</label>
      <input
        value={url}
        onChange={(e) => setUrl(e.target.value)}
        className="mt-2 w-full rounded-lg border border-input bg-card px-4 py-2.5 text-sm focus:border-gold focus:outline-none"
      />
      {isTemp && (
        <p className="mt-2 text-sm text-destructive">
          Este é um endereço temporário. Abra esta página no endereço publicado definitivo antes de descarregar.
        </p>
      )}

      <div className="mt-6 rounded-2xl border border-border bg-cream p-6">
        {preview && <img src={preview} alt="QR Code do menu Villa Sage" className="mx-auto w-full max-w-xs" />}
        <p className="mt-3 text-center font-display text-2xl text-primary-foreground">Villa Sage · Menu</p>
      </div>

      <a
        href={preview || undefined}
        download="villa-sage-menu-qr.png"
        className="mt-6 flex w-full items-center justify-center gap-2 rounded-full bg-primary px-5 py-3.5 font-medium text-primary-foreground hover:opacity-90"
      >
        <Download className="h-5 w-5" /> Descarregar PNG (2048 × 2048)
      </a>
    </div>
  );
}

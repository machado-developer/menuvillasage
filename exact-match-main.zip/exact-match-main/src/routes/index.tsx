import { createFileRoute, Link } from "@tanstack/react-router";
import { MapPin, QrCode, Search, X } from "lucide-react";
import { useMemo, useState } from "react";
import hero from "@/assets/hero.jpg";
import { OrderDialog } from "@/components/OrderDialog";
import { WhatsAppIcon } from "@/components/WhatsAppIcon";
import { ADDRESS, categories, formatKz, WHATSAPP_DISPLAY, WHATSAPP_NUMBER, type MenuItem } from "@/data/menu";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Villa Sage — Menu Digital" },
      { name: "description", content: "Menu digital do restaurante Villa Sage em Benfica, Angola. Consulte pratos e preços e encomende pelo WhatsApp." },
      { property: "og:title", content: "Villa Sage — Menu Digital" },
      { property: "og:description", content: "Consulte o menu do Villa Sage e encomende directamente pelo WhatsApp." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const normalize = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

function Index() {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<MenuItem | null>(null);

  const filtered = useMemo(() => {
    const q = normalize(query.trim());
    if (!q) return categories;
    return categories
      .map((c) => ({ ...c, items: c.items.filter((i) => normalize(i.name + " " + (i.description ?? "")).includes(q)) }))
      .filter((c) => c.items.length > 0);
  }, [query]);

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <header className="relative isolate overflow-hidden">
        <img src={hero} alt="Mesa do Villa Sage com lagosta grelhada" width={1600} height={912} className="absolute inset-0 -z-10 h-full w-full object-cover" />
        <div className="absolute inset-0 -z-10 bg-hero-overlay" />
        <div className="mx-auto max-w-5xl px-5 pb-12 pt-16 text-center sm:pt-24">
          <p className="text-xs uppercase tracking-[0.4em] text-gold">Restaurante</p>
          <h1 className="mt-3 font-display text-6xl font-light tracking-wide text-cream sm:text-8xl">Villa Sage</h1>
          <div className="mx-auto mt-4 h-px w-24 bg-gold" />
          <p className="mt-5 flex items-center justify-center gap-2 text-sm text-cream/85">
            <MapPin className="h-4 w-4 text-gold" /> {ADDRESS}
          </p>
          <a
            href={`https://wa.me/${WHATSAPP_NUMBER}`}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-3 inline-flex items-center gap-2 text-sm text-cream/85 hover:text-gold"
          >
            <WhatsAppIcon className="h-4 w-4 text-gold" /> {WHATSAPP_DISPLAY}
          </a>
        </div>
      </header>

      {/* Sticky search + nav */}
      <div className="sticky top-0 z-30 border-b border-border bg-background/95 backdrop-blur">
        <div className="mx-auto max-w-5xl px-5 pt-3">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Pesquisar pratos ou bebidas…"
              className="w-full rounded-full border border-input bg-card py-2.5 pl-11 pr-10 text-sm placeholder:text-muted-foreground focus:border-gold focus:outline-none"
            />
            {query && (
              <button onClick={() => setQuery("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" aria-label="Limpar">
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
        <nav className="no-scrollbar mx-auto flex max-w-5xl gap-2 overflow-x-auto px-5 py-3">
          {filtered.map((c) => (
            <a
              key={c.id}
              href={`#${c.id}`}
              className="shrink-0 rounded-full border border-border px-4 py-1.5 text-sm text-muted-foreground transition hover:border-gold hover:text-gold"
            >
              {c.name}
            </a>
          ))}
        </nav>
      </div>

      <main className="mx-auto max-w-5xl px-5 py-10">
        {filtered.length === 0 && (
          <p className="py-20 text-center text-muted-foreground">Nenhum resultado para “{query}”.</p>
        )}
        {filtered.map((c, idx) => {
          const showGroup = idx === 0 || filtered[idx - 1]?.group !== c.group;
          return (
            <div key={c.id}>
              {showGroup && c.group === "Bebidas" && (
                <div className="my-14 flex items-center gap-4">
                  <div className="h-px flex-1 bg-border" />
                  <span className="font-display text-2xl italic text-gold">Bebidas</span>
                  <div className="h-px flex-1 bg-border" />
                </div>
              )}
              <section id={c.id} className="mb-14 scroll-mt-32">
                {c.image ? (
                  <div className="relative mb-6 h-40 overflow-hidden rounded-2xl sm:h-56">
                    <img src={c.image} alt={c.name} loading="lazy" width={944} height={704} className="h-full w-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
                    <h2 className="absolute bottom-4 left-5 font-display text-4xl text-cream sm:text-5xl">{c.name}</h2>
                  </div>
                ) : (
                  <h2 className="mb-6 border-b border-border pb-3 font-display text-4xl">{c.name}</h2>
                )}
                {c.note && <p className="mb-5 text-sm italic text-muted-foreground">{c.note}</p>}
                <ul className="grid gap-3 sm:grid-cols-2">
                  {c.items.map((item) => (
                    <li key={item.id} className="flex flex-col justify-between gap-3 rounded-xl border border-border bg-card p-4 transition hover:border-gold/50">
                      <div>
                        <div className="flex items-baseline justify-between gap-3">
                          <h3 className="font-display text-xl leading-snug">{item.name}</h3>
                          <span className="shrink-0 text-sm font-medium text-gold">
                            {item.variants ? item.variants.map((v) => formatKz(v.price)).join(" · ") : formatKz(item.price!)}
                          </span>
                        </div>
                        {item.description && <p className="mt-1 text-sm text-muted-foreground">{item.description}</p>}
                        {item.variants && (
                          <p className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">
                            {item.variants.map((v) => v.label).join(" · ")}
                          </p>
                        )}
                      </div>
                      <button
                        onClick={() => setSelected(item)}
                        className="inline-flex items-center justify-center gap-2 self-start rounded-full border border-whatsapp/60 px-4 py-2 text-sm text-foreground transition hover:bg-whatsapp hover:text-whatsapp-foreground"
                      >
                        <WhatsAppIcon className="h-4 w-4" /> Encomendar pelo WhatsApp
                      </button>
                    </li>
                  ))}
                </ul>
              </section>
            </div>
          );
        })}
      </main>

      <footer className="border-t border-border py-10 text-center text-sm text-muted-foreground">
        <p className="font-display text-2xl text-cream">Villa Sage</p>
        <p className="mt-2">{ADDRESS}</p>
        <p className="mt-1">WhatsApp {WHATSAPP_DISPLAY}</p>
        <Link to="/qr" className="mt-4 inline-flex items-center gap-2 text-gold hover:underline">
          <QrCode className="h-4 w-4" /> QR Code do menu
        </Link>
      </footer>

      <OrderDialog item={selected} onClose={() => setSelected(null)} />
    </div>
  );
}

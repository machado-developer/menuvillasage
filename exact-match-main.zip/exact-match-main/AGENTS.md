<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

# Agent rules

- Menu content (categories, items, prices, WhatsApp number) lives in `src/data/menu.ts` as static data — no database needed for this version.
- QR code is generated client-side on `/qr` from the current origin, so opening it on the published domain yields the definitive QR.
